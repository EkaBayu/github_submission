package com.example.githubuser.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.data.response.FollowersResponseItem
import com.example.githubuser.data.response.FollowingResponseItem
import com.example.githubuser.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Response

class FragmentFollowerViewModel: ViewModel() {
    private val _user = MutableLiveData<List<FollowersResponseItem>>()
    val user : LiveData<List<FollowersResponseItem>> = _user
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> =_isLoading
    private val _followers = MutableLiveData<Int>()
    val follower : LiveData<Int> = _followers
    companion object{
        private const val TAG = "FollowingFramentUser"
    }
    fun getUser(user : String){
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowers(user)
        client.enqueue(object : retrofit2.Callback<List<FollowersResponseItem>> {
            override fun onResponse(
                call: Call<List<FollowersResponseItem>>,
                response: Response<List<FollowersResponseItem>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    if(response.body() != null){
                        _user.value = response.body()
                        _followers.value = response.body()?.size
                    }

                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<FollowersResponseItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure :${t.message.toString()}")
            }
        })

    }
}
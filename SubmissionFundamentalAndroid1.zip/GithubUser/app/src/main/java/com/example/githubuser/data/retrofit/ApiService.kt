package com.example.githubuser.data.retrofit


import com.example.githubuser.data.response.DetailResponse
import com.example.githubuser.data.response.FollowersResponseItem
import com.example.githubuser.data.response.FollowingResponseItem
import com.example.githubuser.data.response.SearchResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users?")
    fun getUser(
        @Query("q") q: String
    ): Call<SearchResponse>
    @GET("users/{username}/followers")
    fun getFollowers(
        @Path("username") user: String
    ): Call <List<FollowersResponseItem>>
    @GET("users/{username}/following")
    fun getFollowing(
        @Path("username") user: String
    ): Call<List<FollowingResponseItem>>
    @GET("users/{username}")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<DetailResponse>

}

package com.example.githubuser.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.githubuser.R
import com.example.githubuser.data.response.DetailResponse
import com.example.githubuser.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    companion object{
         val USERNAME = "username"
         val TAG = "detail"
        @StringRes
    private val TAB_TITTLE = intArrayOf(
        R.string.tab1,
        R.string.tab2
    )


    }
    private var _binding: ActivityDetailBinding? =null
    private val binding get() = _binding!!


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailViewModel::class.java)
        detailViewModel.getUser(intent.getStringExtra(USERNAME).toString())

        detailViewModel.user.observe(this){
            setDetailUser(it)
        }
        detailViewModel.isLoading.observe(this){
            showLoading(it)
        }
        val sectionPagerAdapter = SectionPagerAdapter(this, intent.getStringExtra(USERNAME).toString())
        binding.viewPager.adapter = sectionPagerAdapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager){tab, position ->
        tab.text =resources.getString(TAB_TITTLE[position])

        }.attach()
        supportActionBar?.elevation = 0f

    }
    private fun setDetailUser(user: DetailResponse){
        Glide.with(this)
            .load(user.avatarUrl)
            .into(binding.imgUser)
            binding.tvName.text = user.name
            binding.following.text = user.following.toString() + "" + "Following"
            binding.followers.text = user.followers.toString() + "" + "Followers"
            binding.tvUser.text = user.login



    }
    private fun showLoading(isLoading: Boolean){
        if(isLoading){
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }
}
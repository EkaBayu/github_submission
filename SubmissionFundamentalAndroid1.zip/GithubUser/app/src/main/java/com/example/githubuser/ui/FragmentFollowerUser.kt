package com.example.githubuser.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.data.response.FollowersResponseItem
import com.example.githubuser.databinding.FragmentFollowerUserBinding

class FragmentFollowerUser : Fragment() {
    private var _binding : FragmentFollowerUserBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFollowerUserBinding.inflate(inflater,container,false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val LayoutManager = LinearLayoutManager(context)
        binding.rvfollowers.layoutManager = LayoutManager
        val itemDecoration = DividerItemDecoration(context, LayoutManager.orientation)
        val followersViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FragmentFollowerViewModel::class.java)
        binding.rvfollowers.addItemDecoration(itemDecoration)
        arguments?.let {
            followersViewModel.getUser(arguments?.getString(DetailActivity.USERNAME).toString())
        }
        followersViewModel.follower.observe(viewLifecycleOwner){
            setFollowing(it)
        }
        followersViewModel.user.observe(viewLifecycleOwner){
            setDataRes(it)
        }
        followersViewModel.isLoading.observe(viewLifecycleOwner){
            showLoading(it)
        }
    }

    private fun setDataRes(users: List<FollowersResponseItem>) {
        val adapter = ListFollowersAdapter()
        adapter.submitList(users)
        binding.rvfollowers.adapter = adapter
        Log.d("te","woi jogn")
    }
    private  fun setFollowing(total: Int){

    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}
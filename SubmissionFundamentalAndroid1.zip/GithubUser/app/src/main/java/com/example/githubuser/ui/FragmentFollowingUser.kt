package com.example.githubuser.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.data.response.FollowingResponseItem
import com.example.githubuser.databinding.FragmentFollowingUserBinding


class FragmentFollowingUser : Fragment() {
    private var _binding : FragmentFollowingUserBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFollowingUserBinding.inflate(inflater, container, false)
        val view = binding.root
       return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val LayoutManager = LinearLayoutManager(context)
        binding.rvfollowing.layoutManager = LayoutManager
        val itemDecoration = DividerItemDecoration(context, LayoutManager.orientation)
        val followingViewModel = ViewModelProvider(this,ViewModelProvider.NewInstanceFactory()).get(FragmentFollowingViewModel::class.java)
        binding.rvfollowing.addItemDecoration(itemDecoration)
        arguments?.let {
            followingViewModel.getUser(arguments?.getString(DetailActivity.USERNAME).toString())
        }
          followingViewModel.following.observe(viewLifecycleOwner){
               setFollowing(it)
        }
           followingViewModel.user.observe(viewLifecycleOwner){
                setDataRes(it)
            }
            followingViewModel.isLoading.observe(viewLifecycleOwner){
               showLoading(it)
           }
    }

   private fun setDataRes(users: List<FollowingResponseItem>) {
       val adapter = ListFollowingAdapter()
       adapter.submitList(users)
       binding.rvfollowing.adapter = adapter
        Log.d("te","woi jogn")
    }
   private  fun setFollowing(total: Int){

    }
   private fun showLoading(isLoading: Boolean) {
       if (isLoading) {
          binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
       }
    }
}
package com.example.githubuser.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.data.response.FollowingResponseItem
import com.example.githubuser.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Response


class FragmentFollowingViewModel : ViewModel() {
    private val _user = MutableLiveData<List<FollowingResponseItem>>()
    val user : LiveData<List<FollowingResponseItem>> = _user
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> =_isLoading
    private val _following = MutableLiveData<Int>()
    val following : LiveData<Int> = _following
    companion object{
        private const val TAG = "FollowingFramentUser"
    }
    fun getUser(user : String){
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowing(user)
        client.enqueue(object : retrofit2.Callback<List<FollowingResponseItem>> {
                override fun onResponse(
                    call: Call<List<FollowingResponseItem>>,
                    response: Response<List<FollowingResponseItem>>
                ) {
                    _isLoading.value = false
                    if (response.isSuccessful) {
                        if(response.body() != null){
                            _user.value = response.body()
                            _following.value = response.body()?.size
                        }

                    } else {
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
        }

            override fun onFailure(call: Call<List<FollowingResponseItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure :${t.message.toString()}")
            }
    })

}
}